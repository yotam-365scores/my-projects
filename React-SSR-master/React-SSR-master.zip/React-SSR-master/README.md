# React Server Side Rendering

Sample code to demonstrate React Server Side Rendering.

For the tutorial click [here]( https://medium.com/@danlegion/react-server-side-rendering-with-express-b6faf56ce22)

